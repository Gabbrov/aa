import numpy as np
import math
import pandas as pd
from statistics import mode
from sklearn.utils.validation import check_X_y, check_array, check_is_fitted
from sklearn.utils.multiclass import unique_labels
from sklearn import metrics

class KNNClassifier:
    """
    A basic K-Nearest Neighbour classifier that is compatible with the Scikit-Learn API.
    This will work with both hold-out and cross-validation methods
    from Scikit-Learn.

    Author: Vegard Engen
    Date:   01/11/2021
    """

    def __init__(self, k=3):
        """
        Initialises the K-NN model with, taking an optional argument to set the
        value of k.
        :param k: The number of neighbours used to determine class labels. Must
                  be greater or equal to 2.
        :return: self
        """

        # Validating that k is in fact an integer
        if (type(k) != int):
            raise RuntimeError('The argument k must be an integer')

        # Validating that k is a valid number
        if (k < 2):
            raise RuntimeError('The value of k must be greater or equal to 2')

        # Saving the value of k (so it can be used within other functions of this class)
        self.k = k

        #print("Initialised K-NN with k =", self.k)

    def get_params(self, deep=True):
        """
        Get available model parameters.
        Required by Scikit-Learn.

        :param deep: Not used.
        :return: Dictionary of parameter names and values.
        """
        return {"k": self.k}

    def set_params(self, **parameters):
        """
        Set model parameters.
        Required by Scikit-Learn.

        :param parameters: dictionary of parameters and their values.
        :return: self.
        """
        for parameter, value in parameters.items():
            setattr(self, parameter, value)
        return self

    def fit(self, X, y):
        """
        Saves the X and y data structures, to be used in the predict function.
        :param x: feature matrix
        :param y: labels (vector)
        :return: self
        """

        #print("Training...")
        # Check that X and y have correct shape
        X, y = check_X_y(X, y)

        # Store the classes seen during fit
        self.classes_ = unique_labels(y)

        # Second level validation of k, which should not be greater than half the dataset
        if (self.k >= (X.size/2)):
            raise RuntimeError('k cannot be greater than 50% of the size of the dataset')

        # Save references to X and y
        self.X_train = X
        self.y_train = y

        return self

    def predict(self, X):
        """
        Makes a random prediction
        :param x_test: feature matrix
        :return:
        """

        #print("Testing...")
        # Check is fit has been called
        check_is_fitted(self)

        # Validates input and converts to NumPy array if necessary
        X = check_array(X)

        # Declaring empty array for predictions/classifications
        y_pred = []

        # for each test vector
        for i in range(len(X)): 
            vector_test = X[i]
            neighbour_distances_and_labels = []

            # for each training vector
            for j in range(len(self.X_train)): 
                vector_train = self.X_train[j]
                distance = self.get_euclidean_distance(vector_test, vector_train)
                neighbour_distances_and_labels.append((distance, self.y_train[j]))

            # Sorting by distance (low to high)
            neighbour_distances_and_labels.sort()

            # Get the labels for the k nearest neighbours
            top_k_neighbours_labels = []
            for l in range(self.k):
                top_k_neighbours_labels.append(neighbour_distances_and_labels[l][1])

            # Make a classification based on the majority
            # If a tie, then randomly taking one of the most frequent labels (classes)
            try:
                label = mode(top_k_neighbours_labels)
                y_pred.append(label)
            except StatisticsError:
                print(top_k_neighbours_labels)
                label = max(set(top_k_neighbours_labels), key=top_k_neighbours_labels.count)
                print("Max label:", label)
                y_pred.append(label)

        return y_pred

    def score(self, X, y):
        """
        Default scorer (if none provided).
        Returns accuracy as the score.
        """
        #print("Scoring...")
        return metrics.accuracy_score(self.predict(X), y)

    def get_euclidean_distance(self, vector_train, vector_test):
        """
        Calculates and returns the Euclidean distance between two
        (equal sized) feature vectors.
        """

        # declare and instantiate a variable to accumulate the sum within the for loop below
        sum_diffs = 0

        # iterate over each feature value
        for i in range(len(vector_train)):
            # subtract feature values
            diff = vector_train[i] - vector_test[i]
            sum_diffs += diff ** 2

        return math.sqrt(sum_diffs)


if __name__ == '__main__':
    """
    A main method that trains and tests the classifier on some simple dummy data.
    """

    knn_classifier = KNNClassifier()

    x_train = np.array([[10, 12, 11], [101, 121, 111], [102, 122, 112], [11, 13, 12]])
    y_train = np.array([0, 1, 2, 0])

    x_test = np.array([[10, 12, 11], [101, 121, 111], [102, 122, 112], [10, 12, 11], [101, 121, 111], [102, 122, 112]])

    knn_classifier.fit(x_train, y_train)
    y_pred = knn_classifier.predict(x_test)

    print(y_pred)
