import numpy as np
from sklearn.utils.validation import check_X_y, check_array, check_is_fitted
from sklearn.utils.multiclass import unique_labels
from sklearn import metrics
import pprint

class RandomClassifier:
    """
    A Random Classifier that is compatible with the Scikit-Learn API.
    This will work with both hold-out and cross-validation methods
    from Scikit-Learn.

    Author: Vegard Engen
    Date:   01/11/2021
    """

    def __init__(self, init_msg=None):
        """
        Init function, which takes an optional argument to set and print out
        an init message.

        :param init_msg: Init message string to print, or None (default).
        """
        self.init_msg = init_msg

        if init_msg:
            print(init_msg)

    def get_params(self, deep=True):
        """
        Get available model parameters.
        Required by Scikit-Learn.

        :param deep: Not used.
        :return: Dictionary of parameter names and values.
        """
        return {"init_msg": self.init_msg}

    def set_params(self, **parameters):
        """
        Set model parameters.
        Required by Scikit-Learn.

        :param parameters: dictionary of parameters and their values.
        :return: self.
        """
        for parameter, value in parameters.items():
            setattr(self, parameter, value)
        return self

    def fit(self, X, y):
        """
        Saves the labels for future, random, classification.

        :param Y: feature matrix
        :param y: labels (vector)
        :return: self
        """

        # Check that X and y have correct shape
        X, y = check_X_y(X, y)

        # Store the class labels
        self.classes_ = unique_labels(y)

        return self

    def predict(self, X):
        """
        Makes a random prediction.

        :param X: feature matrix.
        :return: array of predicted class labels.
        """

        # Check is .fit() has been called
        check_is_fitted(self)

        # Validates input and converts to NumPy array if necessary
        X = check_array(X)

        # Initialising empty NumPy integer array
        y_pred = np.array([], int)

        # iterates over all the instances and assigns a random classification to them
        for i in range(len(X)):
            # get random class label from a uniform random number generator from NumPy
            index = np.random.randint(0, len(self.classes_))
            label = self.classes_[index]
            y_pred = np.append(y_pred, label)

        return y_pred

    def score(self, X, y):
        """
        Default scorer (if none provided).
        Required by Scikit-Learn.

        :param X: Feature matrix.
        :param y: Label vector.
        :return: Returns accuracy as the score.
        """
        #print("Scoring...")
        return metrics.accuracy_score(self.predict(X), y)


if __name__ == '__main__':
    random_classifier = RandomClassifier()

    x_train = np.array([[10, 12, 11], [101, 121, 111], [102, 122, 112], [11, 13, 12]])
    y_train = np.array([0, 1, 2, 0])

    x_test = np.array([[10, 12, 11], [101, 121, 111], [102, 122, 112], [10, 12, 11], [101, 121, 111], [102, 122, 112]])

    random_classifier.fit(x_train, y_train)
    y_pred = random_classifier.predict(x_test)

    pprint.pprint(y_pred)
